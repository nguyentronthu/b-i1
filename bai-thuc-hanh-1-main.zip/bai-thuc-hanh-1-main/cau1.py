<?xml version="1.0"?>
<flowgorithm fileversion="2.11">
    <attributes>
        <attribute name="name" value=""/>
        <attribute name="authors" value="Administrator"/>
        <attribute name="about" value=""/>
        <attribute name="saved" value="2021-03-02 04:10:24 PM"/>
        <attribute name="created" value="QWRtaW5pc3RyYXRvcjtBRE1JTjsyMDIxLTAzLTAyOzA0OjA0OjA2IFBNOzMwMDY="/>
        <attribute name="edited" value="QWRtaW5pc3RyYXRvcjtBRE1JTjsyMDIxLTAzLTAyOzA0OjEwOjI0IFBNOzE7MzExMQ=="/>
    </attributes>
    <function name="Main" type="None" variable="">
        <parameters/>
        <body>
            <declare name="r, dt" type="Real" array="False" size=""/>
            <output expression="&quot;nhap gia tri r&quot;" newline="True"/>
            <input variable="r"/>
            <assign variable="dt" expression="r*r*3.14"/>
            <output expression="&quot;dt=&quot;&amp;dt" newline="True"/>
        </body>
    </function>
</flowgorithm>
